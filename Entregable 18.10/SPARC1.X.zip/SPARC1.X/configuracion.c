#pragma config FOSC = INTOSC_HS
#pragma config WDT = OFF  
#pragma config PBADEN = OFF   
#pragma config LVP = OFF  
#pragma config MCLRE = OFF
