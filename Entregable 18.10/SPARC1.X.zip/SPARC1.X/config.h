/* 
 * File:   config.h
 * Author: mausa
 *
 * Created on 26 de octubre de 2019, 10:18 AM
 */

#ifndef CONFIG_H
#define	CONFIG_H

#define _XTAL_FREQ 4000000
#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* CONFIG_H */

