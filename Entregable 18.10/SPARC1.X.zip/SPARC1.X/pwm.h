
void pwm_init(void);
void contador_pulsosD(int pulsoD);
void oneShot();
void clearOneShot();
int keepgoing;