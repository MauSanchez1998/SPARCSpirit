/* 
 * File:   CONFIGURACION1.h
 * Author: mausa
 *
 * Created on 3 de octubre de 2019, 11:26 AM
 */

#ifndef CONFIGURACION1_H
#define	CONFIGURACION1_H

#define _XTAL_FREQ 8000000L

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* CONFIGURACION1_H */

