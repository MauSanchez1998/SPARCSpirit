/*
 * File:   MAINSPARC.c
 * Author: mausa
 *
 * Created on 22 de noviembre de 2019, 10:30 AM
 */

#include <pic18f4550.h>
#include <xc.h>
#include "Comandos.h"
#include "GPIO.h"
#include "CONFIGURACION1.h"
#include "pwm.h"
#include "USARTLIBRERIA.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "Interruptions.h"


void __interrupt() INT_isr(void){
__delay_ms(10);

   
    if(FLAG2==1){
       emergencyButton();
      
       FLAG2=0;
   }
FLAG2=0;
for(int i=0; i < strlen(check); i++){
    USART_Tx(check[i]);
    } 
}
void main(void) {
    OSCCON=0x72;
    
    USART_Init(9600);
    INTCON2bits.RBPU=0;
    gpioInit();
   pwm_init();
   interruptionsInit();
    Enable_D= OFF;
    Enable_I= OFF;
    char instruccion[8];
    
    while(1){
        
        
         EnableRx;  
        for(uint8_t contador=0; contador<9; contador++){
            instruccion[contador]=USART_Rx();
        }
        
        
       for(int i=0; i < 9; i++){
    USART_Tx(instruccion[i]);
    } 
          DisableRx;  
        comandos(instruccion);
        
    }
    
    return;
}
    

